execute at @s run tp @e[type=minecraft:happy_ghast,distance=..80,limit=1] ^ ^ ^3
advancement revoke @s only matcha:mechanics/happy_ghast_horn