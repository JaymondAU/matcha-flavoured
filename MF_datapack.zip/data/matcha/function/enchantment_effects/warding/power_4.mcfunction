#Execute at all entities who quality for being slowed
#On max electrum, copper armour is pierced, and even husks are slowed
execute as @e[distance=..24,type=#matcha:warding_targets] run function matcha:enchantment_effects/warding/effects/apply_slowness.macro {level:2}

#Execute at the nearest valid target, and then check, to see if damage is actually applied
execute as @n[distance=..12,type=#matcha:warding_targets_no_wither] run function matcha:enchantment_effects/warding/effects/check_warding_resistance_2

#This way, the copper-armour-wearers act like a "lightning rod", channelling warding to them, that cannot be applied

#Wither is special, he gets damaged if he is in range no matter what
execute as @n[type=wither,distance=..16] run function matcha:enchantment_effects/warding/effects/apply_damage.macro {damage:2}
